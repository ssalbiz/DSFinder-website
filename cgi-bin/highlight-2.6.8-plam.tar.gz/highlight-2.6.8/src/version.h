/***************************************************************************
                          version.h  -  description
                             -------------------
    begin                : Mon March 3 2003
    copyright            : (C) 2003 by Andre Simon
    email                : andre.simon1@gmx.de
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef VERSION_H
#define VERSION_H

#define HIGHLIGHT_VERSION "2.6.8"

#define HIGHLIGHT_URL "http://www.andre-simon.de/"
#define HIGHLIGHT_EMAIL "andre.simon1@gmx.de"

#endif
