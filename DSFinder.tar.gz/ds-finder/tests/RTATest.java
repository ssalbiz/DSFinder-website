class RTATest {
    void m() { 
	RTATest t = new RTASub(); 
	t.m(); 
    }
}

class RTASub extends RTATest {
    RTASub prev;
    void m() {}
}
