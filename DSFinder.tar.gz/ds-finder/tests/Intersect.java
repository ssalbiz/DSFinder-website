import java.util.List;

class Root { }

class GuiltyChild extends Intersect {
}

class InnocentCousin extends Root {
}

public class Intersect extends Root {
    List<Intersect>   fYES;  // clear intersect
    List<Object>      gYES; 
    List              g1YES; // g, g1 intersect unless we know about the actual parameter type
    List<Root>        hYES; // same as g.
    List<GuiltyChild> iYES;  // can put an Intersect into this list.
    List<InnocentCousin> jNO; // no intersect here
}

