class Simple {
    Simple s;

    public static void main(String[] argv) {
    }
}