import java.util.List;
import java.util.HashMap;

class A {
    B next;

    public static void main(String[] argv) {
	B b = new B();
	b.foo();
    }
}

class B extends A {
    B z;
    A y;
    List<B> children;
    HashMap<A,? super Object> foo;
    List<C> shouldBeFilteredOut;
    List rawType;

    void foo() {
    }
}

class C {}