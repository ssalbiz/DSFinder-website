/* Test N-cycle functionality */
/* Models XMLRoot/XMLNode cycle in Soot. */

public class TwoCycleRoot extends TwoCycleNode {
    TwoCycleNode child;

    public static void main(String[] argv) {
	TwoCycleNode n = new TwoCycleNode();
	TwoCycleRoot r = new TwoCycleRoot();
    }
}

class TwoCycleNode {
    // This is a derived field.
    TwoCycleRoot root;
}
