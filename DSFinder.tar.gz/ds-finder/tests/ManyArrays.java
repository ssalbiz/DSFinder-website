public class ManyArrays {
    Object[] oArray, pArray;
    static int q = 4;
    public static void main(String[] argv) {
	System.out.println(q % 5);
    }
}
