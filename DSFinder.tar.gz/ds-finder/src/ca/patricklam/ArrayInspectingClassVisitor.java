package ca.patricklam;

import org.objectweb.asm.*;
import org.objectweb.asm.commons.*;

/* Only useful to call this when we know that the class
 * we're visiting already has an array of some sort. 
 *
 * Inspects the Class in question for the following pieces of information:
 *  1. does the class have any calls to System.arraycopy;
 *  2. does the class have any array write opcodes;
 *  3. does the class have any mod operations (hashtable proxy). 
 *
 * Ideally we'd pass in the set of relevant arrays and look for writes
 * to these arrays, but that requires building a stack model. */
public class ArrayInspectingClassVisitor extends EmptyVisitor {
    class ArrayUsageInformation {
	boolean containsArrayStore = false;
	boolean containsMod = false;

	boolean callsArrayCopy = false;
	boolean callsHashCode = false;

	public String toString() {
	    StringBuffer sb = new StringBuffer();
	    if (!containsArrayStore) sb.append(" [no-stores]");
	    if (containsMod) sb.append(" [mod]");
	    if (callsArrayCopy) sb.append(" [arraycopy]");
	    if (callsHashCode) sb.append(" [hashcode]");
	    return sb.toString();
	}
    }

    final ArrayUsageInformation info = new ArrayUsageInformation();

    public MethodVisitor visitMethod(int access, String name,
				     String desc, String signature,
				     String[] exceptions) {
	return new ArrayInspectingMethodVisitor();
    }

    class ArrayInspectingMethodVisitor extends EmptyVisitor {
	public void visitInsn(int opcode) {
	    if (opcode == Opcodes.AASTORE)
		info.containsArrayStore = true;
	    if (opcode == Opcodes.IREM || opcode == Opcodes.LREM)
		info.containsMod = true;
	}

	public void visitMethodInsn(int opcode, String owner,
				    String name, String desc) {
	    if (name.equals("arraycopy")) // XXX check System.
		info.callsArrayCopy = true;
	    if (name.equals("hashCode"))
		info.callsHashCode = true;
	}
    }
}

