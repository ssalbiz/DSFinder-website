package ca.patricklam;

import java.util.Arrays;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import java.io.File;
import java.io.InputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ByteArrayInputStream;

import java.util.zip.ZipFile;
import java.util.zip.ZipEntry;

import org.objectweb.asm.*;

import org.objectweb.asm.commons.EmptyVisitor;
import org.objectweb.asm.signature.SignatureVisitor;
import org.objectweb.asm.signature.SignatureReader;
import org.objectweb.asm.signature.SignatureWriter;

public class Resolver {
    public enum Levels { BODIES, SIGNATURES };
    private Map<String, String> classToFile = new HashMap<String, String>();
    private Map<String, Levels> classLevels = new HashMap<String, Levels>();

    public void setLevel(String c, Levels l) {
	classLevels.put(c, l);
    }
    public Levels getLevel(String c) {
	return classLevels.get(c);
    }

    public void setClasspath(String cp) {
	String[] classpath = cp.split(":");
	classToFile = new HashMap<String, String>();

	for (String c : classpath) {
	    File f = new File(c);
	    if (f.isDirectory()) {
		// collect classfiles under f
		recursivelyAdd(c, "", f);
	    } else if (c.endsWith(".jar")) {
	        addJar(c);
	    }
	}
    }

    /* precondition: r.isDirectory() */
    private void recursivelyAdd(String c, String n, File r) {
	String[] children = r.list();
	for (int i = 0; i < children.length; i++) {
	    String cch = c + File.separator + children[i];
	    File cc = new File(cch);
	    if (cc.isDirectory()) {
		String nn;
		if (n.equals("")) 
		    nn = children[i]; 
		else
		    nn = n + File.separator + children[i];

		recursivelyAdd(cch, nn, cc);
	    } else if (children[i].endsWith(".class")) {
		String cs = children[i].substring(0, children[i].length()-6);
		String nn;
		if (n.equals("")) 
		    nn = cs;
		else
		    nn = n + File.separator + cs;

		//System.out.println(nn + " -> " + cch);
		classToFile.put(nn, cch);
	    } //else if (children[i].endsWith(".jar")) {
	    //addJar(children[i]);
	    //}
	}
    }

    private void addJar(String jar) {
	try {
	    Enumeration<ZipEntry> es = (Enumeration<ZipEntry>)(new ZipFile(jar).entries());
	    while (es.hasMoreElements()) {
		ZipEntry e = es.nextElement();
		if (e.getName().endsWith(".class")) {
		    String cs = e.getName().substring
			(0, e.getName().length()-6);
		    classToFile.put(cs, jar);
		}
	    }
	} catch (java.io.IOException ee) { 
	    System.out.println("couldn't open jarfile "+jar+" due to "+ee); 
	}
    }

    public boolean hasClass(String c) {
	return classToFile.containsKey(c);
    }

    public Set<String> getResolvedClasses() {
	return Collections.unmodifiableSet(classToFile.keySet());
    }

    public InputStream openClass(String c) {
	String f = classToFile.get(c);
	// System.out.println("c "+c+" -> "+f);

	if (f == null) return null;

	try {
	    if (f.endsWith(".class"))
		return new FileInputStream(f);
	    else if (f.endsWith(".jar")) {
		ZipFile z = new ZipFile(f);
		ZipEntry entry = z.getEntry(c + ".class");
		return doJDKBugWorkaround(z.getInputStream(entry), entry.getSize());
	    }

	} catch (java.io.IOException e) { System.out.println(e); return null; }
	return null;
    }

    private static InputStream doJDKBugWorkaround(InputStream is, long size) throws IOException {
        
        int sz = (int) size;
        byte[] buf = new byte[sz];                                      
                                
                                    
        final int N = 1024;
        int ln = 0;
        int count = 0;
        while (sz > 0 &&  
               (ln = is.read(buf, count, Math.min(N, sz))) != -1) {
            count += ln;
            sz -= ln;
        }
        return  new ByteArrayInputStream(buf);          
    }

    public DependencyFindingVisitor newDependencyFindingVisitor() {
	return new DependencyFindingVisitor();
    }

    class DependencyFindingVisitor extends ClassAdapter {
	final Set<String> dependencies = new HashSet<String>();
	final Set<String> loadDependencies = new HashSet<String>();

	/* invariant: if we call this with a SKIP_CODE visitor,
	 * loadDependencies should always remain empty. */
	public DependencyFindingVisitor() {
	    super(new org.objectweb.asm.commons.EmptyVisitor());
	}

	public void visit(int version, int access, String name,
			  String signature, String superName, 
			  String[] interfaces) {
	    if (superName != null) {
		//System.out.println ("super "+superName);
		dependencies.add(superName);
	    }

	    for (String i : interfaces) {
		//System.out.println ("interface "+i);
		dependencies.add(i);
	    }
	}

	public FieldVisitor visitField(int access, String name, 
				       String desc, String signature, 
				       Object value) {
	    if (desc != null && desc.charAt(0) != 'L')
		return null;

	    //System.out.println("field "+Type.getType(desc).getClassName());
	    if (signature != null) {
		dependencies.addAll(Util.extractTypesFromSignature(signature));
	    } else
		dependencies.add(Type.getType(desc).getClassName());
	    return null;
	}

	public MethodVisitor visitMethod(int access, String name,
					 String desc, String signature,
					 String[] exceptions) {
	    if (desc == null) return null;

	    SignatureReader sr = new SignatureReader(desc);
	    sr.accept(new SignatureWriter() {
		    public SignatureVisitor visitParameterType() {
			return new SignatureWriter() { 
			    public void visitClassType(String name) {
				//System.out.println("pt "+name);
				dependencies.add(name);
			    } };
		    }
		    public SignatureVisitor visitReturnType() {
			return new SignatureWriter() { 
			    public void visitClassType(String name) {
				//System.out.println("rt "+name);
				dependencies.add(name);
			    } };
		    }
		});
	    return new MethodDependencyVisitor();
	}

	public Set<String> getResolveDependencies() {
	    return Collections.unmodifiableSet(dependencies);
	}

	public Set<String> getLoadDependencies() {
	    return Collections.unmodifiableSet(loadDependencies);
	}

	class MethodDependencyVisitor extends EmptyVisitor {
	    public MethodDependencyVisitor() {
	    }

	    @Override
	    public void visitTypeInsn(int opcode, String type) {
		//handle casts, etc.
		//System.out.println("ti "+type);
		if (Util.strip(type) != null)
		    dependencies.add(Util.strip(type));
	    }
	    
	    @Override
	    public void visitMethodInsn(int opcode, String owner, String name, String desc) {
		//System.out.println("mi "+owner+" name "+name);
		if (Util.strip(owner) != null)
		    loadDependencies.add(Util.strip(owner));
	    }
	    
	    public void visitFieldInsn(int opcode, String owner, String name, String desc) {
		// System.out.println("fi "+owner);
		loadDependencies.add(owner);
	    }
	}
    }
}
