package ca.patricklam;

import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;

import java.io.BufferedWriter;
import java.io.PrintWriter;
import java.io.FileWriter;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Set;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import jargs.gnu.CmdLineParser;

public class DSFinder {
    public static void main(String[] args) {
	DSFinder d = new DSFinder();

	String[] remainingArgs = d.parseCmdLine(args);

	long startTime = System.currentTimeMillis();

	for (String arg : remainingArgs) {
	    String c = Util.unfix(arg);
	    d.classesToAnalyse.add(c);
	    d.loadClass(c);
	}
	d.loadOtherClasses();

	long endTime = System.currentTimeMillis();

	// assume that printReports takes negligible time.
	d.printReports(endTime - startTime);
    }

    public DSFinder() {
	excludedPrefixes.add("sun/");
	excludedPrefixes.add("java/");
	excludedPrefixes.add("javax/");
	excludedPrefixes.add("com/sun/");
	excludedPrefixes.add("org/xml/sax/");
    }

    int debugLevel;
    final int DEBUG_LOADING = 1;
    final int DEBUG_RESOLVING = 2;
    final int DEBUG_PRINT_CLASSNAMES = 4;

    String title;

    final List<String> classesToAnalyse = new LinkedList<String>();
    final List<ClassNode> classes = new LinkedList<ClassNode>();
    final Map<String, ClassNode> classByName = new HashMap<String, ClassNode>();

    Resolver resolver = new Resolver();

    private void printUsage() {
        System.err.println("Usage: DSFinder [-h,--help] [-d,--debug] [-t,--title=STRING] [-c,--classpath=STRING] [-i,--include=path1:path2] [-x,--exclude=path1:path2] [-r,--only-load-referenced] [-s,--report-system-classes] [-p,--report-only-exPlicitly-included]");

    }

    private List<String> includedPrefixes = new LinkedList<String>();
    private List<String> excludedPrefixes = new LinkedList<String>();

    private boolean onlyReportExplicitIncludes = false;
    private boolean onlyLoadReferenced = false;

    public String[] parseCmdLine(String[] args) {
	results.put("args", Arrays.asList(args).toString());

	CmdLineParser parser = new CmdLineParser();
	CmdLineParser.Option help = parser.addBooleanOption('h', "help");
	CmdLineParser.Option debug = parser.addIntegerOption('d', "debug");
	CmdLineParser.Option classpath = parser.addStringOption('c', "classpath");
	CmdLineParser.Option titleOpt = parser.addStringOption('t', "title");

	/* These options control the set of classes for which we emit
	 * reports. */
	CmdLineParser.Option include = parser.addStringOption('i', "include");
	CmdLineParser.Option exclude = parser.addStringOption('x', "exclude");

	/* These options affect class loading.
	 * 2) default: load all files in classpath and report on everything,
	 *              don't report on system libraries
         * 3) -r:      only load transitively referenced classes, starting
	 *              at the classes specified on command line
	 *
         * These options affect reporting.
	 * 1) -s:      load all files in classpath and report on everything,
	 *              including system libraries. (clears -x).
	 * 4) -p:      only report on classes in the explicitly included pkgs.
	*/
	CmdLineParser.Option reportSystemClassesOpt = parser.addBooleanOption('s', "report-system-classes");
	// default is here
	CmdLineParser.Option onlyLoadReferencedOpt = parser.addBooleanOption('r', "only-load-referenced");
	CmdLineParser.Option onlyReportExplicitIncludesOpt = parser.addBooleanOption('p', "report-only-exPlicitly-included");

        try {
            parser.parse(args);
        }
        catch ( CmdLineParser.OptionException e ) {
            System.err.println(e.getMessage());
            printUsage();
            System.exit(2);
        }

	if ((Boolean)parser.getOptionValue(help, Boolean.FALSE)) {
            printUsage();
            System.exit(0);
	}

	debugLevel = (Integer)parser.getOptionValue(debug, new Integer(0));
	title = (String)parser.getOptionValue(titleOpt, "dsOut");
	onlyReportExplicitIncludes = (Boolean)parser.getOptionValue
	    (onlyReportExplicitIncludesOpt, Boolean.FALSE);
	onlyLoadReferenced = (Boolean)parser.getOptionValue
	    (onlyLoadReferencedOpt, Boolean.FALSE);
	if ((Boolean)parser.getOptionValue(reportSystemClassesOpt, 
					   Boolean.FALSE)) 
	    excludedPrefixes.clear();

	resolver.setClasspath((String)parser.getOptionValue(classpath, ""));

	String ip = (String)parser.getOptionValue(include);
	if (ip != null)
	    includedPrefixes.addAll(Arrays.asList(ip.split(":")));

	String ep = (String)parser.getOptionValue(exclude);
	if (ep != null)
	    excludedPrefixes.addAll(Arrays.asList(ep.split(":")));

	return parser.getRemainingArgs();
    }

    /* Diagnostic: returns all classes that appear in a classpath
     * but never loaded. */
    private List<String> computeUntouchedClasses() {
	List<String> untouchedClasses = new LinkedList<String>();
	for (String c : resolver.getResolvedClasses()) {
	    for (String p : includedPrefixes)
		if (c.startsWith(p)) untouchedClasses.add(c);
	}

	for (ClassNode c : classes) {
	    untouchedClasses.remove(c.name);
	}
	return untouchedClasses;
    }

    /* Postcondition: computeUntouchedClasses() returns {}. */
    public void loadOtherClasses() {
	if (!onlyLoadReferenced) {
	    for (String c : resolver.getResolvedClasses())
		for (String p : includedPrefixes)
		    if (c.startsWith(p)) loadClass(c);
	}
    }

    public void loadClass(String c) {
	try {
	    if (resolver.getLevel(c) == Resolver.Levels.BODIES)
		return;

	    if ((debugLevel & DEBUG_LOADING) != 0) 
		System.out.println("Loading class "+c);

	    resolver.setLevel(c, Resolver.Levels.BODIES);

	    InputStream cis = resolver.openClass(c);
	    ClassReader r = new ClassReader(cis);
	    cis.close();

	    Resolver.DependencyFindingVisitor dfv = 
		resolver.newDependencyFindingVisitor();
	    r.accept (dfv, 
		      ClassReader.SKIP_DEBUG | 
		      ClassReader.SKIP_FRAMES);

	    ClassNode cn = new ClassNode();
	    r.accept (cn, ClassReader.SKIP_DEBUG);
	    if (classByName.get(Util.fix(cn.name)) == null) {
		classes.add(cn);
		classByName.put(Util.fix(cn.name), cn);
	    }

	    // System.out.println(dfv.getLoadDependencies());
	    for (String d : dfv.getLoadDependencies()) {
		loadClass(Util.unfix(d));
	    }

	    for (String d : dfv.getResolveDependencies()) {
		resolveClass(Util.unfix(d));
	    }
	} catch (IOException e) {
	    System.err.println("io exception loading "+c);
	}
    }

    public void resolveClass(String c) {
	try {
	    if (resolver.getLevel(c) != null)
		return;

	    if (resolver.getLevel(c) != Resolver.Levels.BODIES)
		resolver.setLevel(c, Resolver.Levels.SIGNATURES);

	    if ((debugLevel & DEBUG_RESOLVING) != 0)
		System.out.println("Resolving class "+c);

	    InputStream cis = resolver.openClass(c);
	    ClassReader r = new ClassReader(cis);
	    cis.close();

	    Resolver.DependencyFindingVisitor dfv = 
		resolver.newDependencyFindingVisitor();
	    r.accept (dfv, 
		      ClassReader.SKIP_CODE | ClassReader.SKIP_DEBUG | 
		      ClassReader.SKIP_FRAMES);

	    ClassNode cn = new ClassNode();
	    r.accept (cn, ClassReader.SKIP_DEBUG);

	    classes.add(cn);
	    classByName.put(Util.fix(cn.name), cn);

	    for (String d : dfv.getResolveDependencies()) {
		if (!classByName.containsKey(Util.fix(d))) {
		    resolveClass(Util.unfix(d));
		}
	    }
	} catch (IOException e) {
	    System.err.println("io exception resolving "+c+": " +e.toString());
	}
    }

    final Map<ClassNode, List<FieldNode>> cycles = new HashMap<ClassNode, List<FieldNode>>();
    final Map<ClassNode, List<FieldNode>> collections = new HashMap<ClassNode, List<FieldNode>>();
    final Map<ClassNode, List<FieldNode>> arrays = new HashMap<ClassNode, List<FieldNode>>();
    final Map<ClassNode, List<ClassNode>> g = new HashMap<ClassNode, List<ClassNode>>();
    private int collectionCount = 0;

    public final List COLLECTIONS_MAPS = Collections.unmodifiableList(Arrays.asList( new String[] { "java.util.Collection", "java.util.Map"}));
    public final String JAVA_LANG_OBJECT = "Ljava/lang/Object;";
    public final String JAVA_LANG_STRING = "Ljava/lang/String;";

    public final String JAVA_LANG_OBJECT_fixed = "java.lang.Object";
    public final String JAVA_LANG_STRING_fixed = "java.lang.String";

    private Map<ClassNode, Boolean> cache = new HashMap<ClassNode, Boolean>();
    public boolean isCollection(ClassNode c) {
        if (c == null) return false;
	if (cache.containsKey(c)) return cache.get(c);
	if (COLLECTIONS_MAPS.contains(Util.fix(c.name))) return true;

	for (String i : (List<String>)c.interfaces) {
	    if (classByName.containsKey(Util.fix(i)) && isCollection(classByName.get(Util.fix(i)))) {
		cache.put(classByName.get(Util.fix(i)), true); 
		return true;
	    }
	}

	if (c.superName == null) {
	    cache.put(c, false);
	    return false;
	}

	boolean rv = isCollection(classByName.get(Util.fix(c.superName)));
	cache.put(c, rv);
	return rv;
    }

    public boolean isSubclass(ClassNode parent, ClassNode child) {
	ClassNode c = child;
	for (String iface : (List<String>)parent.interfaces) {
           if (c.name.equals(iface))
	     return true;
	}
	while (true) {
	    if (c.name.equals(parent.name))
		return true;
	    if (c.superName == null)
		return false;

	    c = classByName.get(Util.fix(c.superName));
	    if (c == null) 
	      return false;
	}
    }

    private void mainPass() {
	// collect 0-cycles and create containment graph 'g'
	for (ClassNode appClass : classes) {
	    if (skipClass(appClass.name)) continue;

	    if ((debugLevel & DEBUG_PRINT_CLASSNAMES) != 0)
		System.out.println(appClass.name);

	    if (g.get(appClass) == null)
		g.put(appClass, new LinkedList<ClassNode>());

	    for (FieldNode field : (List<FieldNode>)appClass.fields) {
		//ignore static fields & synthetic ones
		if ((field.access & Opcodes.ACC_STATIC) != 0
		    || (field.access & Opcodes.ACC_SYNTHETIC) != 0) continue;

		handleField(appClass, field);


	    }

	    for (MethodNode method : (List<MethodNode>)appClass.methods) {
	      countInstantiations(appClass, method, null, null); //count system instantiations
	    }
	}
    }

    //runs through methodNodes to count instantiations of successfully classified data structures
    private void secondPass(List<String> customDataStructures) {
      List<String> instantiatingClasses = new LinkedList<String>();
      for (ClassNode appClass : classes) {
        if (skipClass(appClass.name)) continue;

	ArrayInspectingClassVisitor cv = new ArrayInspectingClassVisitor();
        try {
         InputStream cis = resolver.openClass(appClass.name);
         ClassReader r = new ClassReader(cis);
         r.accept (cv, ClassReader.SKIP_DEBUG | ClassReader.SKIP_FRAMES);
         cis.close();
        } catch (IOException e) {
          System.err.println("io exception reloading "+appClass.name);
        }

	for (MethodNode method : (List<MethodNode>)appClass.methods) {
	  countInstantiations(appClass, method, customDataStructures, instantiatingClasses);
	  if (cv.info.callsArrayCopy || cv.info.callsHashCode || cv.info.containsMod)
	    countArrayInstantiations(appClass, method, arrays.get(appClass));
	}
	for (FieldNode field : (List<FieldNode>)appClass.fields) {
	  countDeclarations(appClass, field, customDataStructures);
	}
      }
      //make another pass to grab the container instantiations now that the list of containers has been populated
      for (ClassNode appClass : classes) {
        for (MethodNode method : (List<MethodNode>)appClass.methods) {
	  countInstantiations(appClass, method, null, instantiatingClasses);
	}
      }
    }

    private void countArrayInstantiations(ClassNode c, MethodNode method, List<FieldNode> arrayDS) {
      Iterator i = method.instructions.iterator();
      AbstractInsnNode inst;
      while(i.hasNext()) {
        inst = (AbstractInsnNode)i.next();
        if (inst.getOpcode() == Opcodes.NEWARRAY) {
          increment(arrayInstantiationCounts, Util.fix(c.name));
	}
      }
    }


    final Map<String, String> containeeCounts = new HashMap<String, String>();
    final Map<String, String> customContaineeCounts = new HashMap<String, String>();
    final Map<String, String> ipContaineeCounts = new HashMap<String, String>();
    final Map<String, String> instantiationCounts = new HashMap<String, String>();
    final Map<String, String> customInstantiationCounts = new HashMap<String, String>();
    final HashMap<String, String> customCollectionsCounts = new HashMap<String, String>();
    final Map<String, String> arrayInstantiationCounts = new HashMap<String, String>();
    final Map<String, String> customContainerInstantiationCounts = new HashMap<String, String>();

    private void countDeclarations(ClassNode c, FieldNode f, List<String> customDS) {
      Type ft = Type.getType(f.desc);
      if (customDS != null && customDS.contains(ft.getClassName()))
        increment (customCollectionsCounts, ft.getClassName());
    }

    private void countInstantiations(ClassNode c, MethodNode method, List<String> customDS, List<String> containerDS) {
      Iterator i = method.instructions.iterator();
      AbstractInsnNode inst;
      while(i.hasNext()) {
        inst = (AbstractInsnNode)i.next();
	
	if (inst.getOpcode() == Opcodes.NEW) {
	 String owner = ((TypeInsnNode)inst).desc;
         //System.out.println( ((MethodInsnNode)inst).owner + ":" + ((MethodInsnNode)inst).name     );
	 if (customDS != null && customDS.contains(Util.fix(owner))) {
	    increment(customInstantiationCounts, Util.fix(owner));
	    if (!containerDS.contains(c.name))
	      containerDS.add(Util.fix(c.name));
	 }
	 else if (customDS == null && containerDS != null && containerDS.contains(Util.fix(owner))) {
	   increment(customContainerInstantiationCounts, Util.fix(owner));
	 }  
	 else if (containerDS == null 
	          && customDS == null 
		  && classByName.get(Util.fix(owner)) != null 
		  && isCollection(classByName.get(Util.fix(owner)))) {
            increment(instantiationCounts, Util.fix(owner));
	 }
	}

      }
    }

    private void handleField(ClassNode c, FieldNode field) {
	Type ft = Type.getType(field.desc);
	if (ft.getSort() == Type.OBJECT) {
	    ClassNode ftc = classByName.get(ft.getClassName());
	    if (ftc == null) {
		System.out.println("phantom class: "+ft.getClassName());
		return;
	    }
	    
	    // update 'g' for N-cycle check
	    if (!skipClass(ftc.name))
		g.get(c).add(ftc);
	    
	    if (isSubclass(ftc, c) || isSubclass(c, ftc)) {
		List<FieldNode> l = cycles.get(c);
		if (l == null) {
		    l = new LinkedList<FieldNode>();
		    cycles.put(c, l);
		}
		l.add(field);
	    } //else {
	    /* handle parametric types */
		
	    // can omit if the parameter types definitely
	    // do not intersect this-type
		
	    // only include java.util.Collection, java.util.Maps
	    if (!isCollection(ftc))
	      return;
		
	    boolean allOK = true;
		
	    String s = field.signature;
	    //System.out.println("got field signature "+s +" for field "+field.name);
	    if (s != null) {
              String[] tokens = s.split("[;<>]");
		    
	    // Check that other parameters do not intersect c.
	    for (int i = 1; i < tokens.length; i++) {
	      String ss = tokens[i];
	      if (ss.startsWith("L")) {
	        String pname = Util.fix(ss.substring(1));
		ClassNode param = classByName.get(pname);		    
	        // we are disjoint on type parameter cc if
	        // cc is not a superclass or superclass of appClass.
			    			    
		if (isSubclass(param, c) || isSubclass(c, param))
		  allOK = false;

	        if (pname.equals(JAVA_LANG_OBJECT_fixed))
	          increment(results, "objectsInCollections");
		else if (pname.equals(JAVA_LANG_STRING_fixed))
		  increment(results, "stringsInCollections");

	        boolean custom = false;
		for (String ip : includedPrefixes) {
	          String ipp = Util.fix(ip);
		  if (pname.startsWith(ipp)) {
		    increment(ipContaineeCounts, ipp);
		    increment(customContaineeCounts, pname);
		    custom = true;
	          }
				
	        }
	        if (!custom) increment(containeeCounts, pname);
	      } else if (ss.startsWith("T")) {
		increment(results, "templatesInCollection");
		allOK = false; // type parameter; might intersect C.
	      }
	    }
          } else { 
		    increment(results, "unknownInCollection");
		    allOK = false;
	  }
		
	  if (!allOK)
	    addToMap(collections, c, field);
          else { 
	    increment(results, "notDataStructures");
          }
	   //}
	} else if (ft.getSort() == Type.ARRAY) {
	    // throw out primitive type arrays. they're not data structures.
	    while (ft.getSort() == Type.ARRAY)
		ft = ft.getElementType();

	    if (ft.getSort() != Type.OBJECT)
		return;

	    addToMap(arrays, c, field);
	}
    }

    private void increment(Map<String, String> m, String key) {
	if (!m.containsKey(key))
	    m.put(key, "0");
	int i = Integer.parseInt(m.get(key))+1;
	m.put(key, Integer.toString(i));
    }

    private void addToMap(Map<ClassNode, List<FieldNode>> m, ClassNode c, FieldNode f) {
	List<FieldNode> l = m.get(c);
	if (l == null) {
	    l = new LinkedList<FieldNode>();
	    m.put(c, l);
	}
	
	l.add(f);
    }

    // relies on mainPass() having successfully run.
    private void collateCollections(PrintWriter outFull) {
	outFull.println();
	outFull.println("COLLECTIONS REPORT");
	outFull.println("==================");
	outFull.println();
	
	List<ClassNode> collectionsKeys = new ArrayList<ClassNode>();
	collectionsKeys.addAll(collections.keySet());
	Collections.sort(collectionsKeys, new ClassComparator());
	
	final HashMap<String, String> collectionsCounts = 
	    new HashMap<String, String>();
	LinkedList<String> collectionsContainers = new LinkedList<String>();

	outFull.println("Whitelisted: Possible compound data structures");
	for (ClassNode c : collectionsKeys) {
	  List<FieldNode> toRemove = new LinkedList<FieldNode>();
	  for (FieldNode f : collections.get(c)) {
	    if (!skipClass(c.name) && containsWhiteListedKey(f.name)) {
	      outFull.println(Util.summarizeField(c, f));
	      String fcn = Type.getType(f.desc).getClassName();
	      increment(collectionsCounts, fcn);
	      toRemove.add(f);
	    }
	  }
	  collections.get(c).removeAll(toRemove);
	}
	outFull.println("=="); 

	for (ClassNode c : collectionsKeys) {
	    for (FieldNode f : collections.get(c)) {
		if (!skipClass(c.name)) {
		    outFull.println(Util.summarizeField(c, f));
		    
		    String fcn = Type.getType(f.desc).getClassName();
		    increment (collectionsCounts, fcn);
		}
	    }
	}
	results.put("topCollections", 
		    formatTopN(5, collectionsCounts));
	results.put("topContainees", 
		    formatTopN(5, containeeCounts));
	results.put("topCustomContainees", 
	            formatTopN(5, customContaineeCounts));
	results.put("topInstantiations",
	            formatTopN(5, instantiationCounts));
	results.put("topCustomInstantiations",
	            formatTopN(5, customInstantiationCounts));
	results.put("topCustomCollections",
		   formatTopN(5, customCollectionsCounts));
	results.put("topContainerInstantiations",
		   formatTopN(5, customContainerInstantiationCounts));

	StringBuffer cc = new StringBuffer();
	for (String ip : ipContaineeCounts.keySet()) {
	    String l = " total "+ip+"*";
	    String tabs = "\t\t\t\t\t\t".substring(0, (56 - l.length()+7) / 8);
	    cc.append(l+tabs+ipContaineeCounts.get(ip)+"\n");
	}
	results.put("customContainees", cc.toString());
    }

    private String formatTopN(int N, final Map<String, String> ct) {
	List<String> r = new LinkedList<String>(); r.addAll(ct.keySet());
	Collections.sort(r, 		
			 new Comparator<String>() {
			     public int compare (String a, String b) {
				 return Integer.parseInt(ct.get(b)) - Integer.parseInt(ct.get(a)); }});
	
	StringBuffer topCollections = new StringBuffer();
	int bdry = N, leftovers = 0;

	if (r.size() < bdry) 
	    bdry = r.size();
	
	for (int i = 0; i < bdry; i++) {
	    String n = r.get(i);
	    if (n.length() >= 56) //truncate field names longer than fixed report width
	      n = "..." + n.substring(n.length()-56+4);

	    String tabs = "\t\t\t\t\t\t".substring(0, (56 - n.length()+7) / 8);
	    topCollections.append(n.replaceAll("\\$", "\\\\\\$")+tabs+ct.get(r.get(i))+"\n");
	}
	for (int i = bdry; i < r.size(); i++)
	    leftovers += Integer.parseInt(ct.get(r.get(i)));
	
	topCollections.append("Others\t\t\t\t\t\t\t"+leftovers+"\n");
	return topCollections.toString();
    }

    private void handleArrays(PrintWriter outFull) {
	outFull.println();
	outFull.println("ARRAYS REPORT");
	outFull.println("=============");
	outFull.println();
	
	List<ClassNode> arraysKeys = new ArrayList<ClassNode>();
	arraysKeys.addAll(arrays.keySet());
	Collections.sort(arraysKeys, new ClassComparator());
	int nowrites = 0, copied = 0, hashtables = 0, errorbars = 0;

	results.put("arrayInstantiations",
	   formatTopN(5, arrayInstantiationCounts));

	for (ClassNode c : arraysKeys) {
	    ArrayInspectingClassVisitor cv = new ArrayInspectingClassVisitor();
	    try {
		InputStream cis = resolver.openClass(c.name);
		ClassReader r = new ClassReader(cis);
		r.accept (cv, ClassReader.SKIP_DEBUG | ClassReader.SKIP_FRAMES);
		cis.close();
	    } catch (IOException e) { 
		System.err.println("io exception reloading "+c.name);
	    }

	    for (FieldNode f : arrays.get(c)) {
		if (!skipClass(c.name))
		    outFull.println(Util.summarizeField(c, f, cv.info.toString()));
	    }

	    boolean added = false;
	    if (!cv.info.containsArrayStore) {
		nowrites += arrays.get(c).size();
		added = true;
	    }
	    if (cv.info.callsArrayCopy) {
		copied += arrays.get(c).size();
		added = true;
	    }
	    if (cv.info.callsHashCode || cv.info.containsMod) {
		hashtables += arrays.get(c).size();
		added = true;
	    }
	    if (added && arrays.get(c).size() > 1)
		errorbars += arrays.get(c).size();
	}
	results.put("arrays", Integer.toString(arraysKeys.size()));
	results.put("arrayNoWrites", Integer.toString(nowrites));
	results.put("arrayCopy", Integer.toString(copied));
	results.put("arrayHashtables", Integer.toString(hashtables));
	results.put("arrayErrors", Integer.toString(errorbars));
    }

    /** Collect N-cycles.
     * We don't deal with n-cycles which use collections, e.g.
     * class A { List<B> b; } class B { List<A> cycle; }
     * A other problem is that we can't reach e.g. XMLNode from
     * soot.Main through g, since it only contains field relationships.
	*/

    private void handleNCycles(PrintWriter outFull) {
	List<List<ClassNode>> components = new LinkedList<List<ClassNode>>();
	List<ClassNode> visitedClasses = new LinkedList<ClassNode>();
	for (ClassNode appClass : classes) {
	    if (visitedClasses.contains(appClass))
		continue;

	    SCC<ClassNode> sccs = new SCC<ClassNode>(g, appClass, visitedClasses);
	    components.addAll(sccs.getTrueComponents());
	    visitedClasses.addAll(sccs.getVisitedNodes());
	}

	outFull.println();
	outFull.println("N-CYCLES");
	outFull.println("========");
	
	for (List<ClassNode> scc : components) {
	    if (scc.size() <= 1) continue;
	    
	    outFull.print("[");
	    
	    java.util.Iterator<ClassNode> ci = scc.iterator();
	    while (ci.hasNext()) {
		ClassNode c = ci.next();
		outFull.print(c.name);
		if (ci.hasNext()) outFull.print(", ");
	    }
	    outFull.println("]");
	}
	results.put("nCycles", Integer.toString(components.size()));
    }
	
    public void printReports(long runtime) {
	mainPass();

	try {
	    PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(title)));
	    PrintWriter outFull = new PrintWriter(new BufferedWriter(new FileWriter(title+"-full")));

	    String rts = "DSFinder has run for "
		+ (runtime / 60000)
		+ " min. "
		+ ((runtime % 60000) / 1000)
		+ " sec.";
	    out.println(rts); outFull.println(rts);

	    outFull.println();
	    outFull.println("0-CYCLES REPORT");
	    outFull.println("===============");
	    outFull.println();

	    // next/prev

	    HashSet<ClassNode> dataStructureContainers = 
		new HashSet<ClassNode>();

	    List<ClassNode> cycleContainers = new LinkedList<ClassNode>();
	    for (ClassNode c : cycles.keySet()) {
		cycleContainers.add(c);
	    }

	    Collections.sort(cycleContainers, new ClassComparator());
	    int nextPrevCount = 0;
            List<String> potentialDataStructures = new LinkedList<String>();

            outFull.println();
	    outFull.println("Blacklisted, likely not data structures:");
	    int blacklistCount = 0;
	    for (ClassNode c : cycleContainers) {
	      List<FieldNode> toRemove = new LinkedList<FieldNode>();
	      for (FieldNode f : cycles.get(c)) {
	        if (!Type.getType(f.desc).getClassName().equals(Util.fix(c.name))
		    && containsBlackListedKey(f.name)
		    || containsBlackListedType(Type.getType(f.desc).getClassName())) {
		  blacklistCount++;
		  outFull.println(Util.summarizeField(c, f));
		  toRemove.add(f);
		}
	      }
	      cycles.get(c).removeAll(toRemove);
	    }
            outFull.println();

	    outFull.println("Linked List-like Data Structures:");
	    for (ClassNode c : cycleContainers) {
		List<FieldNode> toRemove = new LinkedList<FieldNode>();
		for (FieldNode f : cycles.get(c)) {
		    String fl = f.name.toLowerCase();
		    if (fl.contains("next") || fl.contains("prev")) {
			// try to consolidate next/prev
			// if they have the same modifiers
			if (fl.startsWith("next")) {
			    for (FieldNode ff : cycles.get(c)) {
				String ffl = ff.name.toLowerCase();
				if (ffl.startsWith("prev") &&
				    (fl.substring(4).
				     equals(ffl.substring(4)) ||
				     (ffl.length() >= 8 && 
				      ffl.substring(4, 8).equals("ious") &&
				      ffl.substring(8).equals(fl.substring(4)))) && 
				    f.access == ff.access &&
				    (f.desc == null || 
				     f.desc.equals(ff.desc)) &&
				    (f.signature == null || 
				     f.signature.equals(ff.signature))) {
				    // print next/prev as one field.
				    toRemove.add(f);
				    f = new FieldNode(f.access,
						      f.name+"/"+ff.name,
						      f.desc, f.signature,
						      f.value);
				}
			    }
			} else if (fl.startsWith("prev")) {
			    for (FieldNode ff : cycles.get(c)) {
				String ffl = ff.name.toLowerCase();
				if (ffl.startsWith("next") &&
				    (ffl.substring(4).
				     equals(fl.substring(4)) ||
				     (fl.substring(4, 8).equals("ious") &&
				      fl.substring(8).equals(ffl.substring(4)))) && 
				    f.access == ff.access &&
				    (f.desc == null || 
				     f.desc.equals(ff.desc)) &&
				    (f.signature == null || 
				     f.signature.equals(ff.signature))) {
				    toRemove.add(f);
				    f = null;
				    break;
				}
			    }
			} 

			if (f != null) {
			    dataStructureContainers.add(c);
			    outFull.println(Util.summarizeField(c, f));
			    nextPrevCount++;
			    toRemove.add(f);
			    potentialDataStructures.add(Util.fix(c.name));
			}
		    }
		}
		cycles.get(c).removeAll(toRemove);
	    }
	    
	    // parent
	    
	    outFull.println();
	    outFull.println("Parent- and outer-type Data Structures:");

	    int parentCount = 0;
	    for (ClassNode c : cycleContainers) {
		List<FieldNode> toRemove = new LinkedList<FieldNode>();
		for (FieldNode f : cycles.get(c)) {
		    if (f.name.contains("parent") ||
			f.name.contains("outer")) {
			outFull.println(Util.summarizeField(c, f));
			toRemove.add(f);
			dataStructureContainers.add(c);
			parentCount++;
			potentialDataStructures.add(Util.fix(c.name));
		    }
		}
		cycles.get(c).removeAll(toRemove);
	    }
	    
	    outFull.println();
	    outFull.println("Whitelisted, probable data structures:");
	    int whitelistCount = 0;
	    for (ClassNode c : cycleContainers) {
	      List<FieldNode> toRemove = new LinkedList<FieldNode>();
	      for (FieldNode f : cycles.get(c)) {
	        if (Type.getType(f.desc).getClassName().equals(Util.fix(c.name))
		    && containsWhiteListedKey(f.name)) {
		  whitelistCount++;
		  outFull.println(Util.summarizeField(c, f));
		  toRemove.add(f);    
		  potentialDataStructures.add(Util.fix(c.name));
		}
	      }
	      cycles.get(c).removeAll(toRemove);
	    }

	    outFull.println();

	    outFull.println();
	    outFull.println("Others:");
	    outFull.println("Exact Field Matches:");
	    int otherCount = 0, objectCount = 0, exactOtherCount = 0;


	    for (ClassNode c : cycleContainers) {
	      List<FieldNode> toRemove = new LinkedList<FieldNode>();
	      for (FieldNode f : cycles.get(c)) {
		if (Type.getType(f.desc).getClassName().equals(Util.fix(c.name))) {
		  exactOtherCount++;
		  otherCount++;
	          outFull.println(Util.summarizeField(c, f));
		  toRemove.add(f);
		}
	      }
	      cycles.get(c).removeAll(toRemove);
	    }

	    outFull.println("Non-Object Fields:");
	    
	    for (ClassNode c : cycleContainers) {
	      List<FieldNode> toRemove = new LinkedList<FieldNode>();
	      for (FieldNode f : cycles.get(c)) {
		if (!f.desc.equals(JAVA_LANG_OBJECT)) {
		  otherCount++;
	          outFull.println(Util.summarizeField(c, f));
		  toRemove.add(f);
		}
	      }
	      cycles.get(c).removeAll(toRemove);
	    }
	   

	    outFull.println("java.lang.Object Fields:");
	    for (ClassNode c : cycleContainers) {
	      for (FieldNode f : cycles.get(c)) {
		  objectCount++;
		  otherCount++;
	          outFull.println(Util.summarizeField(c, f));
	      }
	    }



	    results.put("linkedList", Integer.toString(nextPrevCount));
	    results.put("parents", Integer.toString(parentCount));
	    results.put("whitelisted", Integer.toString(whitelistCount));
	    results.put("blacklisted", Integer.toString(blacklistCount));
	    results.put("others", Integer.toString(otherCount));
	    results.put("objOthers", Integer.toString(objectCount));
	    results.put("nonobjOthers", Integer.toString(otherCount - objectCount));
	    results.put("exactOthers", Integer.toString(exactOtherCount));
	    results.put("distinctClassCount", Integer.toString(dataStructureContainers.size()));
	    results.put("potentialDataStructures", Integer.toString(collections.size()));
	    //TODO: refactor to eliminate redundant data structures
            secondPass(potentialDataStructures);
	    collateCollections(outFull);
	    handleArrays(outFull);
	    handleNCycles(outFull);

	    int nonFiltered=0;
	    for (ClassNode c : classes) {
		if (!skipClass(c.name)) nonFiltered++;
	    }

	    results.put("count", Integer.toString(nonFiltered));
	    results.put("totalCount", Integer.toString(classes.size()));

	    out.println(getSubstitutedSummary());
	    out.close(); outFull.close();
	} catch (java.io.IOException e) {}
    }


    String[] whitelist = {"child", "edge", "vertex"};
    String[] blacklist = {"target", "arg", "param", "dir", "this", "lock", "key", "value", "data"};
    String[] blacklistTypes = {"java.lang.Throwable", "java.awt", "javax.swing", "java.util.Properties"};

    //identify field variable names indicative of data structure members
    private boolean containsWhiteListedKey(String fieldName) {
      for (String name : whitelist) {
        if (fieldName.toLowerCase().contains(name))
	  return true;
      }
      return false;
    }
    
    //identify field variable names indicative of false positives
    private boolean containsBlackListedKey(String fieldName) {
      
      for (String name : blacklist) {
        if (fieldName.toLowerCase().contains(name))
	  return true;
      }
      return false;
    }

    //identify field typings not designed to be used as data structure members
    private boolean containsBlackListedType(String fieldType) {
      for (String type : blacklistTypes) {
        if (fieldType.contains(type))
	  return true;
      }
      return false;
    }

    /* Affects reporting: if skipClass returns true, information from
     * the class s should not appear in any reports (except counts of
     * total number of classes). */
    private boolean skipClass(String s) {
	for (String p : excludedPrefixes)
	    if (s.startsWith(p)) return true;

	if (onlyReportExplicitIncludes) {
	    if (includedPrefixes.size() > 0) {
		for (String p : includedPrefixes)
		    if (s.startsWith(p)) return false;
		
		return true;
	    }
	}

	return false;
    }

    class ClassComparator<T extends ClassNode> implements java.util.Comparator<T> {
	public int compare (T a, T b) {
	    return a.name.compareToIgnoreCase(b.name);
	}
    }

    // #variables:
    // #count - number of classes
    // #totalCount - classes, including libraries
    // #linkedList - linked-list-like
    // #parents - parent/outer
    // #others - other potentially self-referential types
    // #objOthers - self-referential only because field type is Object
    // #nonobjOthers - #others - #objOthers
    // #distinctClassCount - #linkedList + #parents, each class counts once
    // #nCycles - count of N-cycles in fields
    //!#topCollections - collection usage (top-5)
    //!#arrays - number of arrays
    //!#arrayNoWrites - arrays without any arraysets in the defining class
    //!#arrayCopy - arrays with a nearby System.arraycopy call
    //!#arrayHashtables - arrays with a % calculation nearby
    //!#notDataStructures - collections proved disjoint from defining type
    //!#potentialDataStructures - collections which could implement trees,
    //                            graphs, etc
    //!#stringsInCollections - collections declared to contain java.lang.String
    //!#objectsInCollections - collections declared to contain java.lang.Object
    //!#unknownInCollection - collections for which we just don't know

    // #inclPrefix - the -include-pkg paths
    // #inclPrefixInCollections - collections declared to contain a class in
    //                            the include-pkg
    Map<String, String> results = new HashMap<String, String>(); 

    public String getSubstitutedSummary() {
	String rv = summaryFormatString;
	Pattern p = Pattern.compile("#(\\w*)");
	Matcher m = p.matcher(rv);
	while (m.find()) {
	    rv = m.replaceFirst(substituteValue(m.group(1)));
	    m.reset(rv);
	}
	return rv;
    }

    private String substituteValue(String key) {
	if (results.containsKey(key))
	    return results.get(key);
	return "0";
    }

    final private String summaryFormatString = 
	"SUMMARY\n"+
	"=======\n"+
	"\n"+
	"args: #args\n"+
	"Processed #count non-library classes (#totalCount with libraries.)\n" +
	"\n"+
	"COUNTS OF IMPLEMENTATIONS\n"+
	"=========================\n"+
	"\n"+
	"Linked lists\t\t\t\t\t\t#linkedList\n"+
	"Parents/outers\t\t\t\t\t\t#parents\n"+
	"Others (#objOthers java.lang.Object, #nonobjOthers non-Object fields)\t#others\n"+
        " exact matching fields\t\t\t\t\t#exactOthers\n"+
	"\n"+
	"Distinct classes containing linked lists and parents:\t#distinctClassCount\n"+
	"\n"+
	"N-cycles\t\t\t\t\t\t#nCycles\n"+
	"\n"+
	"Arrays\t\t\t\t\t\t\t#arrays\n"+
	"\t read-only:\t\t\t\t\t#arrayNoWrites\n"+
	"\t w/arraycopy:\t\t\t\t\t#arrayCopy\n"+
	"\t hashtable-like:\t\t\t\t#arrayHashtables\n"+
	"\t (error bars:) [3]\t\t\t\t#arrayErrors\n"+
	"\n"+
	"DECLARED SYSTEM COLLECTION FIELDS, BY IMPLEMENTING CLASS\n"+
	"========================================================\n"+
        "#topCollections\n"+
	"\n"+
	"DECLARED AD-HOC COLLECTION FIELDS, BY IMPLEMENTING CLASS\n"+
	"========================================================\n"+
        "#topCustomCollections\n"+
	"\n"+
	"INSTANTIATED SYSTEM COLLECTIONS (counts of `new' statements)\n"+
	"============================================================\n"+
	"#topInstantiations\n"+
	"\n"+
	"INSTANTIATED AD-HOC COLLECTIONS\n"+
	"===============================\n"+
	"#topCustomInstantiations\n"+
	"\n"+
	"INSTANTIATED AD-HOC COLLECTION CONTAINERS\n"+
	"=========================================\n"+
	"#topContainerInstantiations\n"+
	"\n"+
	"INSTANTIATED ARRAYS\n"+
	"===================\n"+
	"#arrayInstantiations\n"+
	"\n"+
	"DECLARED COLLECTION PARAMETER TYPES [1]\n"+
	"=======================================\n"+
	"Collections are not data structures [2]\t\t\t#notDataStructures\n"+
	"Collections are potential data structures\t\t#potentialDataStructures\n"+
	"\n"+
	"#customContainees\n"+
	"java.lang.String\t\t\t\t\t#stringsInCollections\n"+
	"java.lang.Object\t\t\t\t\t#objectsInCollections\n"+
	"Ad-Hoc types:\n"+
	"=============\n"+
	"#topCustomContainees\n"+
	"System types:\n"+
	"==============\n"+
	"#topContainees\n"+
	"TEMPLATE PARAMETERS\t\t\t\t\t#templatesInCollection\n"+
	"UNKNOWN\t\t\t\t\t\t\t#unknownInCollection\n"+
	"\n"+
	"[1] sums to more than count of non-array collections: consider HashMap<A,B>.\n"+
	"[2] e.g. class Foo { List<String> NotDataStructure; }\n"+
	"[3] number of counted arrays in classes with multiple arrays.\n";
}
