package ca.patricklam;

import java.util.List;
import java.util.ArrayList;
import java.util.Comparator;

import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.FieldNode;
import org.objectweb.asm.Type;
import org.objectweb.asm.Opcodes;

public class Util {
    public static String fix(String n) {
	return n.replaceAll("/", ".");
    }

    public static String unfix(String n) {
	return n.replaceAll("\\.", "/");
    }

    public static String summarizeField(ClassNode c, FieldNode f) {
	return summarizeField(c, f, "");
    }

    public static String summarizeField(ClassNode c, FieldNode f, String extra) {
	return fix(c.name) + ": " + 
	    ((!fix(c.name).equals(Type.getType(f.desc).getClassName())) ? 
	     ("*"+Type.getType(f.desc).getClassName()+"* ") : "") +
	    ((f.access & Opcodes.ACC_PRIVATE) != 0 ? "[private] ":"") +
	    ((f.access & Opcodes.ACC_PUBLIC) != 0 ? "[public] ":"") +
	    ((f.access & Opcodes.ACC_PROTECTED) != 0 ? "[protected] ":"") +
	    ((f.access & Opcodes.ACC_STATIC) != 0 ? "[static] ":"") +
	    ((f.access & Opcodes.ACC_FINAL) != 0 ? "[final] ":"") +
	    f.name + 
	    (f.signature != null ? 
	     (" [" + f.signature + "]") : "") + extra;
    }

    /** Converts 'owner' strings (as in MethodInsn) into class names.
     * If n is just a raw class name, returns n.
     * If n is an array type (e.g. [Ljava/lang/Object), returns java/lang/Object.
     * If n is [?, where ? != L, returns null. */
    public static String strip(String n) {
	if (n.charAt(0) != '[')
	    return n;

	if (n.startsWith("[L"))
	    return n.substring(2, n.length() - 1);

	return null;
    }

    /** Return types in a signature, ignoring any type
     * parameters. e.g. Ljava/util/List<Ljava/util/Object;Lfoo/Bar>;
     * will return [java/util/List, java/util/Object, foo/Bar]. */
    public static List<String> extractTypesFromSignature(String sig) {
	ArrayList<String> rv = new ArrayList<String>();
	String[] tokens = sig.split("[;<>]");

	for (int i = 0; i < tokens.length; i++) {
	    String ss = tokens[i];
	    if (ss.startsWith("L"))
		rv.add(ss.substring(1));
	}
	return rv;
    }
}

class FieldComparator implements Comparator<FieldNode> {
    public int compare(FieldNode a, FieldNode b) {
	int n = a.signature.compareToIgnoreCase(b.signature);
	if (n != 0)
	    return n;

	return a.name.compareToIgnoreCase(b.name);
    }
}

