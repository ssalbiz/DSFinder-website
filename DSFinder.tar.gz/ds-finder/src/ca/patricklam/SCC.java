package ca.patricklam;

import java.util.*;

// From Soot's StronglyConnectedComponentsFast (Eric Bodden)
class SCC<N> {
    private final List<List<N>> componentList = new ArrayList<List<N>>();
    private final List<List<N>> trueComponentList = new ArrayList<List<N>>();
    private final List<N> visitedNodes = new ArrayList<N>();
    
    private int index = 0;
    
    private Map<N,Integer> indexForNode, lowlinkForNode;
    
    private Stack<N> s;
    private Map<N,List<N>> g;
    private List<N> alreadyVisited;
    
    private void recurse(N v) {
	visitedNodes.add(v);

	indexForNode.put(v, index);
	lowlinkForNode.put(v, index);
	index++;

	if (alreadyVisited.contains(v))
	    return;

	s.push(v);
	
	List<N> vSuccs = g.get(v);
	if (vSuccs == null) vSuccs = Collections.EMPTY_LIST;
	
	for(N succ: vSuccs) {
	    if(!indexForNode.containsKey(succ)) {
		recurse(succ);
		lowlinkForNode.put(v, Math.min(lowlinkForNode.get(v), lowlinkForNode.get(succ)));
	    } else if(s.contains(v)) {
		lowlinkForNode.put(v, Math.min(lowlinkForNode.get(v), indexForNode.get(succ)));
	    }                       
	}
	if(lowlinkForNode.get(v)==indexForNode.get(v)) {
	    List<N> scc = new ArrayList<N>();
	    N v2;
	    do {
		v2 = s.pop();
		scc.add(v2);
	    }while(v!=v2);                  
	    componentList.add(scc);
	    if(scc.size()>1) {
		trueComponentList.add(scc);
	    } else {
		N n = scc.get(0);
		if(g.get(n) != null && g.get(n).contains(n))
		    trueComponentList.add(scc);
	    }
	}
    }
    
    SCC(Map<N, List<N>> g, N start, List<N> alreadyVisited) {
	this.g = g;
	this.alreadyVisited = alreadyVisited;
	s = new Stack<N>();
	List<N> heads = new LinkedList<N>();
	heads.add(start);
	
	if(heads.size()>1)
	    throw new RuntimeException("Cannot compute SCCs for graph with number of heads = "+heads.size());
	
	indexForNode = new HashMap<N, Integer>();
	lowlinkForNode = new HashMap<N, Integer>();
	
	recurse(heads.get(0));
	
	//free memory
	indexForNode = null;
	lowlinkForNode = null;
	s = null;
    }
    
    public List<List<N>> getTrueComponents() {
	return trueComponentList;
    }

    public List<N> getVisitedNodes() {
	return Collections.unmodifiableList(visitedNodes);
    }
}
